scReg-Eval PeerJ CS AI-in-code supplemental archive
Supplemental Data S3
File: Supplemental_Data_S3_resulting_code.zip
Resulting (post-engineering) copies of the three analysis scripts.
Auxiliary engineering disclosure only.
Companion archives: Supplemental Data S1 (original code), S2 (prompts), S3 (resulting code).
Production code remains src/v2/ in the repository.
