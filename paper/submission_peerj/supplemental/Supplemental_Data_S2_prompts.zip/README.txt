scReg-Eval PeerJ CS AI-in-code supplemental archive
Supplemental Data S2
File: Supplemental_Data_S2_prompts.zip
Reconstructed prompt log for the three disclosed engineering edits.
Auxiliary engineering disclosure only.
Companion archives: Supplemental Data S1 (original code), S2 (prompts), S3 (resulting code).
Production code remains src/v2/ in the repository.
