scReg-Eval PeerJ CS AI-in-code supplemental archive
Supplemental Data S1
File: Supplemental_Data_S1_original_code.zip
Original (pre-engineering) copies of the three analysis scripts.
Auxiliary engineering disclosure only.
Companion archives: Supplemental Data S1 (original code), S2 (prompts), S3 (resulting code).
Production code remains src/v2/ in the repository.
